# detach-tab
Available on <a href="https://addons.mozilla.org/en-US/firefox/addon/detach-tab/">AMO</a>.
